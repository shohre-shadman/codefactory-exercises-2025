# nutrition_table

tried to only use things we already learned.
feel free to ask why or how i did something onsite.
